import Foundation

struct CardData: Decodable {
    let cards: [Card]
}

struct Card: Decodable {
    let name: String
    let type: String
    let manaCost: String?
    let setName: String?
}

enum APIError: Error {
    case invalidURL
    case connectionError(Error)
    case serverError(Int)
    case unknownError
}

func buildUrl(name: String) -> URL? {
    var componets = URLComponents()
    componets.scheme = "https"
    componets.host = "api.magicthegathering.io"
    componets.path = "/v1/cards"
    componets.queryItems = [URLQueryItem(name: "name", value: name)]
    return componets.url
}

func getData(from url: URL, completion: @escaping (Result<CardData, APIError>) -> Void) {
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let error = error {
            completion(.failure(.connectionError(error)))
            return
        }
        
        guard let httpResponse = response as? HTTPURLResponse else {
            completion(.failure(.unknownError))
            return
        }
        
        switch httpResponse.statusCode {
        case 200:
            guard let data = data else {
                completion(.failure(.unknownError))
                return
            }
            
            let decoder = JSONDecoder()
            
            do {
                let json = try decoder.decode(CardData.self, from: data)
                completion(.success(json))
            } catch let error as NSError {
                completion(.failure(.connectionError(error)))
            }
            
        case 404:
            completion(.failure(.invalidURL))
            
        default:
            completion(.failure(.serverError(httpResponse.statusCode)))
        }
    }.resume()
}


let cardsRequest = ["Black Lotus", "Ornithopter"]

for card in cardsRequest {
    getData(from: buildUrl(name: card)!) { result in
        switch result {
        case .success(let cardData):
            print("Имя карты: "+cardData.cards[0].name)
            print("Тип: "+cardData.cards[0].type )
            print("Мановая стоимость: "+(cardData.cards[0].manaCost ?? "Нет данных"))
            print("Название сета: "+(cardData.cards[0].setName ?? "Нет данных"))
            print("------------------")
            
        case .failure(let error):
            switch error {
            case .invalidURL:
                print("Неправильный URL")
            case .connectionError(let error):
                print("Ошибка соединения: \(error.localizedDescription)")
            case .serverError(let statusCode):
                print("Ошибка сервера: \(statusCode)")
            case .unknownError:
                print("Неизвестная ошибка")
            }
        }
    }
}
